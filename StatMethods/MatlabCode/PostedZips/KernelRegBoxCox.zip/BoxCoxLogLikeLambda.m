function negLogLik = BoxCoxLogLikeLambda(lambda,y,geoMeanY,H)

n = length(y);
yTilde = BoxCoxTrans(y,lambda)/(geoMeanY^(lambda-1));
negLogLik = (yTilde'*H*yTilde)/n;

